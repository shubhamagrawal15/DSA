package Strings.Hard;

public class SumofBeautyofAllSubstrings {
    public static void main(String[] args) {
        String s = "xyx";
        int[] map=new int[256];
        for (int i = 0; i <s.length() ; i++) {
            map[s.charAt(i)]++;
        }
        for (int i = 0; i <map.length ; i++) {
            if(map[i]>0){
                System.out.println((char)i+" -> "+map[i]);
            }
        }
    }
}
