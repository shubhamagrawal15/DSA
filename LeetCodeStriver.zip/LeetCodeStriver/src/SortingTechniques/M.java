package SortingTechniques;

public class M {
    public static void main(String[] args) {


         String str1="Shubham";
         String str2 = new String("Shubham");

        System.out.println(str1==str2);
        System.out.println(str1.equals(str2));


        int num = 10;
        System.out.println(num++);
        System.out.println(++num);
    }
}
